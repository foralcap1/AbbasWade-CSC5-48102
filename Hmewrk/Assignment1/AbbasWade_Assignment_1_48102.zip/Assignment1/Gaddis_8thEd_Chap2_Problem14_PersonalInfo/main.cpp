/* 
   File:   main
   Author: Abbas, Wade
   Created on September 20th, 2016, 9:29 AM
   Purpose: Displaying Information Program  
 */

//System Libraries
#include <iostream>   //Input/Output objects
using namespace std;  //Name space used in the System Library



//User Libraries

//Global Constants

//Function prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declaration of Variables


    
    
    //Process values -> Map inputs to Outputs

        
    //Display Output
        cout<<"        Personal Information\n\n         Name: Wade Abbas" 
                "\n      Address: 5555 Tan Grape Dr."
                "\n               Loma Linda, Ca 92354\n  "
                "      Phone: 9095551628\n      College\n        Major: "
                "Computer Science\n ";
        
    
    
    //Exit Program
    return 0;
}